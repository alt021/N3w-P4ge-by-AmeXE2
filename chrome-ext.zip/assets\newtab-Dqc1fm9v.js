(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))n(a);new MutationObserver(a=>{for(const i of a)if(i.type==="childList")for(const m of i.addedNodes)m.tagName==="LINK"&&m.rel==="modulepreload"&&n(m)}).observe(document,{childList:!0,subtree:!0});function s(a){const i={};return a.integrity&&(i.integrity=a.integrity),a.referrerPolicy&&(i.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?i.credentials="include":a.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(a){if(a.ep)return;a.ep=!0;const i=s(a);fetch(a.href,i)}})();const c={theme:"theme",showTitle:"showTitle",showTime:"showTime",showGo:"showGo",searchEngine:"searchEngine",showDots:"showDots",backgroundStyle:"backgroundStyle",lang:"lang",clockFormat:"clockFormat",searchStyle:"searchStyle",showShortcuts:"showShortcuts",showClickFx:"showClickFx"},I={google:"https://www.google.com/search?q=",duckduckgo:"https://duckduckgo.com/?q=",qwant:"https://www.qwant.com/?q=",bing:"https://www4.bing.com/search?q=",baidu:"https://www.baidu.com/s?wd="},z=["browser","google","duckduckgo","qwant","bing","baidu"],Y={en:{searchTitle:"Search title",timeDisplay:"Time Display",showGo:"Search button",background:"Background",blankBackground:"Blank",dotBackground:"Dot Grid",stripeBackground:"Stripes",showShortcuts:"Shortcuts",clickEffects:"Click Effects",theme:"Theme",auto:"Auto",light:"Light",dark:"Dark",searchEngine:"Search Engine",browserDefault:"Browser Default",google:"Google",duckduckgo:"DuckDuckGo",qwant:"Qwant",bing:"Bing",baidu:"Baidu",language:"Language",english:"English",chinese:"中文",clockFormat:"Clock Format",clock12h:"12-hour",clock24h:"24-hour",placeholder:"Type to search...",go:"Go",searchStyle:"Search Box Style",square:"Square",rounded:"Rounded",line:"Line",bookmarks:"Bookmarks",bookmarksBar:"Bookmarks Bar",otherBookmarks:"Other Bookmarks",folder:"Folder",history:"History",more:"More",downloads:"Downloads",extensions:"Extensions"},zh:{searchTitle:"显示标题",timeDisplay:"时间显示",showGo:"搜索按钮",background:"背景",blankBackground:"空白",dotBackground:"点阵",stripeBackground:"条纹",showShortcuts:"快捷方式",clickEffects:"点击特效",theme:"主题",auto:"自动",light:"浅色",dark:"深色",searchEngine:"搜索引擎",browserDefault:"跟随浏览器",google:"Google",duckduckgo:"DuckDuckGo",qwant:"Qwant",bing:"Bing",baidu:"百度",language:"语言",english:"English",chinese:"中文",clockFormat:"时钟格式",clock12h:"12小时制",clock24h:"24小时制",placeholder:"输入搜索内容...",go:"前往",searchStyle:"搜索框样式",square:"方形",rounded:"圆角矩形",line:"横线",bookmarks:"书签",bookmarksBar:"收藏夹栏",otherBookmarks:"其他收藏夹",folder:"文件夹",history:"历史",more:"更多",downloads:"下载",extensions:"扩展"}};function l(e){return Y[S()][e]||e}function h(e,t,s){const n=localStorage.getItem(e);return t.includes(n)?n:s}function g(e,t){localStorage.setItem(e,t)}function V(){return(navigator.language||navigator.userLanguage||"").toLowerCase().startsWith("zh")?"zh":"en"}function S(){const e=localStorage.getItem(c.lang);if(e==="en"||e==="zh")return e;const t=V();return g(c.lang,t),t}function N(e){document.documentElement.setAttribute("data-theme",e),g(c.theme,e)}function B(){const e=document.querySelector(".prompt"),t=h(c.showTitle,["true","false"],"true")==="true";e.classList.toggle("hidden",!t)}function w(){const e=document.getElementById("time"),t=h(c.showTime,["true","false"],"false")==="true";if(!e||(e.classList.toggle("hidden",!t),!t))return;const s=new Date;if(h(c.clockFormat,["12","24"],"24")==="12"){const a=s.getHours(),i=a>=12?"PM":"AM",m=a%12||12;e.textContent=`${String(m).padStart(2,"0")}:${String(s.getMinutes()).padStart(2,"0")} ${i}`}else e.textContent=s.toLocaleTimeString("en-US",{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit"})}function x(){const e=localStorage.getItem(c.backgroundStyle),t=h(c.showDots,["true","false"],"true")==="true"?"dots":"blank",s=e==="blank"||e==="dots"||e==="stripes"?e:t;document.body.classList.remove("bg-blank","bg-dots","bg-stripes"),document.body.classList.add(`bg-${s}`)}let E=!1;function A(){const e=h(c.showClickFx,["true","false"],"true")==="true";e&&!E?(document.addEventListener("mousedown",M),E=!0):!e&&E&&(document.removeEventListener("mousedown",M),E=!1)}function M(e){const t=["var(--fg)","var(--muted)","var(--border)"];for(let s=0;s<18;s++){const n=Math.PI*2*s/18+(Math.random()-.5)*.5,a=80+Math.random()*200,i=Math.cos(n)*a,m=Math.sin(n)*a,r=2+Math.random()*5,u=400+Math.random()*400,o=document.createElement("div");o.className="px px-burst",o.style.left=e.clientX+"px",o.style.top=e.clientY+"px",o.style.width=r+"px",o.style.height=r+"px",o.style.background=t[Math.floor(Math.random()*t.length)],o.style.setProperty("--life",u+"ms"),document.body.appendChild(o);const d=performance.now();(function b(f){const p=Math.min((f-d)/u,1),C=1-p*p;o.style.left=e.clientX+i*p*C+"px",o.style.top=e.clientY+m*p*C+60*p*p+"px",p<1?requestAnimationFrame(b):o.remove()})(d)}}function R(){const e=document.querySelector(".search-go"),t=h(c.showGo,["true","false"],"true")==="true";e&&e.classList.toggle("hidden",!t)}function O(){const e=document.getElementById("search-form"),t=h(c.searchStyle,["square","rounded","line"],"square");e&&(e.classList.remove("style-square","style-rounded","style-line"),e.classList.add(`style-${t}`))}function T(){const e=document.getElementById("shortcuts"),t=h(c.showShortcuts,["true","false"],"true")==="true";e&&e.classList.toggle("hidden",!t),document.querySelectorAll(".shortcut-item[data-i18n]").forEach(n=>{const a=n.getAttribute("data-i18n");a&&(n.textContent=l(a))})}function k(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}const H=`MIT License

Copyright (c) 2025 AmeXE2

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.`;let y=0;const X={zh:{pages:[`<div class="onboarding-center">
         <div class="onboarding-emoji">👋</div>
         <div class="onboarding-title">欢迎使用AmeXE2的新标签页</div>
         <div class="onboarding-subtitle">一个现代 · 极简 · 纯净的浏览器主页</div>
       </div>`,`<div class="onboarding-col">
         <div class="onboarding-title">开源说明与使用许可</div>
         <div class="onboarding-subtitle">请仔细阅读相关说明</div>
         <div class="onboarding-scroll">
           <h3>扩展说明</h3>
           <ol>
             <li>本项目为Vibe Coding产物，仅供作者自用。代码质量较差，如有需要请自行重构或修改。</li>
             <li>本扩展完全离线运行，不收集、上传或存储任何有关于您的数据或信息。</li>
             <li>为实现快捷方式功能，本扩展需要您的历史记录和书签的访问权限，数据仅在本地存储，不会被上传或收集。</li>
           </ol>
           <h3>开源说明</h3>
           <pre style="white-space:pre-wrap;font-family:inherit;margin:0.5rem 0">${k(H)}</pre>
         </div>
       </div>`,`<div class="onboarding-col">
         <div class="onboarding-title">使用方法</div>
         <div class="onboarding-subtitle">点按右键打开设置菜单</div>
         <img class="onboarding-img" src="scrshot.png" alt="右键菜单截图">
       </div>`,`<div class="onboarding-center">
         <div class="onboarding-emoji">🎉</div>
         <div class="onboarding-title">欢迎使用</div>
       </div>`],btns:["开始","同意","继续","完成"],hint:"滚动阅读至底部后可进行下一步"},en:{pages:[`<div class="onboarding-center">
         <div class="onboarding-emoji">👋</div>
         <div class="onboarding-title">Welcome to AmeXE2 New Tab</div>
         <div class="onboarding-subtitle">A modern · minimal · clean browser homepage</div>
       </div>`,`<div class="onboarding-col">
         <div class="onboarding-title">Open Source & License</div>
         <div class="onboarding-subtitle">Please read the following carefully</div>
         <div class="onboarding-scroll">
           <h3>About This Extension</h3>
           <ol>
             <li>This project is a Vibe Coding product, intended for personal use only. Code quality may be poor — feel free to refactor or modify as needed.</li>
             <li>This extension runs entirely offline. It does not collect, upload, or store any of your data or information.</li>
             <li>To enable shortcuts, this extension requires access to your history and bookmarks. Data is stored locally only and is never uploaded or collected.</li>
           </ol>
           <h3>Open Source License</h3>
           <pre style="white-space:pre-wrap;font-family:inherit;margin:0.5rem 0">${k(H)}</pre>
         </div>
       </div>`,`<div class="onboarding-col">
         <div class="onboarding-title">How to Use</div>
         <div class="onboarding-subtitle">Right-click to open the settings menu</div>
         <img class="onboarding-img" src="scrshot.png" alt="Context menu screenshot">
       </div>`,`<div class="onboarding-center">
         <div class="onboarding-emoji">🎉</div>
         <div class="onboarding-title">Enjoy!</div>
       </div>`],btns:["Start","Agree","Continue","Finish"],hint:"Scroll to the bottom to proceed"}};function _(){if(localStorage.getItem("onboardingDone")==="true")return;const e=S(),t=X[e],s=document.createElement("div");s.className="onboarding-overlay",s.id="onboarding-overlay";const n=document.createElement("div");n.className="onboarding-dialog";const a=document.createElement("div");a.className="onboarding-slider";const i=[];t.pages.forEach((b,f)=>{const p=document.createElement("div");p.className="onboarding-panel",p.innerHTML=b,p.style.transform=`translateX(${f*100}%)`,a.appendChild(p),i.push(p)});const m=document.createElement("div");m.className="onboarding-footer";const r=document.createElement("div");r.className="onboarding-hint hidden",r.textContent=t.hint;const u=document.createElement("button");u.className="onboarding-btn",u.textContent=t.btns[0];let o=!1;function d(){if(u.textContent=t.btns[y],y===1){if(o){u.disabled=!1,r.classList.add("hidden");return}u.disabled=!0,r.classList.remove("hidden");const b=i[1].querySelector(".onboarding-scroll");if(b){const f=()=>{b.scrollTop+b.clientHeight>=b.scrollHeight-4&&(o=!0,u.disabled=!1,r.classList.add("hidden"),b.removeEventListener("scroll",f))};b.removeEventListener("scroll",f),b.addEventListener("scroll",f)}}else u.disabled=!1,r.classList.add("hidden")}u.addEventListener("click",()=>{if(y++,y>3){localStorage.setItem("onboardingDone","true"),s.classList.remove("visible"),setTimeout(()=>s.remove(),300);return}i.forEach((b,f)=>{b.style.transform=`translateX(${(f-y)*100}%)`}),d()}),m.appendChild(r),m.appendChild(u),n.appendChild(a),n.appendChild(m),s.appendChild(n),document.body.appendChild(s),requestAnimationFrame(()=>s.classList.add("visible"))}function D(){const e=document.getElementById("sidebar-overlay"),t=document.getElementById("sidebar-panel");e&&e.classList.remove("visible"),t&&t.classList.remove("visible")}function F(e){const t=document.getElementById("sidebar-overlay"),s=document.getElementById("sidebar-panel"),n=s==null?void 0:s.querySelector(".sidebar-header h3"),a=s==null?void 0:s.querySelector(".sidebar-content"),i=s==null?void 0:s.querySelector(".sidebar-footer-link"),m=document.getElementById("sidebar-more");if(!t||!s||!a)return;n&&(n.textContent=l(e==="bookmarks"?"bookmarks":"history")),a.innerHTML="";const r=e==="bookmarks"?"chrome://bookmarks":"chrome://history";m&&(m.innerHTML='<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M6.25 4.5A1.75 1.75 0 0 0 4.5 6.25v11.5c0 .966.783 1.75 1.75 1.75h11.5a1.75 1.75 0 0 0 1.75-1.75v-4a.75.75 0 0 1 1.5 0v4A3.25 3.25 0 0 1 17.75 21H6.25A3.25 3.25 0 0 1 3 17.75V6.25A3.25 3.25 0 0 1 6.25 3h4a.75.75 0 0 1 0 1.5h-4ZM13 3.75a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 .75.75v6.5a.75.75 0 0 1-1.5 0V5.56l-5.22 5.22a.75.75 0 0 1-1.06-1.06l5.22-5.22h-4.69a.75.75 0 0 1-.75-.75Z"/></svg>',m.title=l("more"),m.onclick=()=>{typeof chrome<"u"&&chrome.tabs&&chrome.tabs.create({url:r})}),i&&(i.onclick=()=>{typeof chrome<"u"&&chrome.tabs&&chrome.tabs.create({url:r})}),e==="bookmarks"?j(a):K(a),t.classList.add("visible"),s.classList.add("visible")}function j(e){e.innerHTML="";const t=document.createElement("div");t.className="sidebar-tabs";const s=document.createElement("div");s.className="sidebar-tab-indicator",t.appendChild(s);const n=document.createElement("div");n.className="sidebar-bookmark-content";const a=[{id:"1",label:l("bookmarksBar")},{id:"2",label:l("otherBookmarks")}],i=[];let m="1";function r(o){const d=t.getBoundingClientRect(),b=o.getBoundingClientRect();s.style.left=b.left-d.left+"px",s.style.width=b.width+"px"}function u(o,d){o!==m&&(m=o,i.forEach(b=>b.classList.toggle("active",b===d)),r(d),n.style.animation="none",n.offsetHeight,n.style.animation="fadeIn 0.2s ease",q(n,o))}for(const o of a){const d=document.createElement("button");d.className="sidebar-tab"+(o.id==="1"?" active":""),d.textContent=o.label,d.addEventListener("click",()=>u(o.id,d)),t.appendChild(d),i.push(d)}e.appendChild(t),e.appendChild(n),requestAnimationFrame(()=>{const o=i.find(d=>d.classList.contains("active"));o&&r(o)}),q(n,"1")}async function q(e,t){if(e.innerHTML="",typeof chrome>"u"||!chrome.bookmarks){e.innerHTML='<div class="sidebar-empty">Chrome API not available</div>';return}try{const n=(await chrome.bookmarks.getSubTree(t))[0];if(!n||!n.children||n.children.length===0){const a=document.createElement("div");a.className="sidebar-empty",a.textContent="EMPTY",e.appendChild(a);return}U(e,n.children)}catch{const s=document.createElement("div");s.className="sidebar-empty",s.textContent="EMPTY",e.appendChild(s)}}function U(e,t){for(const s of t)if(s.children){const n=document.createElement("div");n.className="bookmark-folder";const a=document.createElement("button");a.className="bookmark-folder-header",a.innerHTML=`
        <span class="bookmark-folder-arrow-cell">
          <svg class="bookmark-folder-arrow" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 2.5L8 6L4.5 9.5"/></svg>
        </span>
        <div class="bookmark-folder-info">
          <div class="bookmark-folder-name">${k(s.title||"Untitled")}</div>
          <div class="bookmark-folder-type">${l("folder")}</div>
        </div>
      `;const i=document.createElement("div");i.className="bookmark-folder-children",a.addEventListener("click",()=>{const m=n.classList.toggle("open"),r=a.querySelector(".bookmark-folder-arrow");r&&(r.style.transform=m?"rotate(90deg)":"")}),U(i,s.children),n.appendChild(a),n.appendChild(i),e.appendChild(n)}else if(s.url){const n=document.createElement("button");n.className="sidebar-item",n.innerHTML=`
        <div class="sidebar-item-title">${k(s.title||s.url)}</div>
        <div class="sidebar-item-url">${k(s.url)}</div>
      `,n.addEventListener("click",()=>{window.location.href=s.url}),e.appendChild(n)}}async function K(e){if(typeof chrome>"u"||!chrome.history){e.innerHTML='<div class="sidebar-empty">Chrome API not available</div>';return}try{const t=Date.now()-6048e5,s=await chrome.history.search({text:"",startTime:t,maxResults:80});if(!s||s.length===0){e.innerHTML='<div class="sidebar-empty">No history</div>';return}for(const n of s){if(!n.url)continue;const a=document.createElement("button");a.className="sidebar-item";const i=n.lastVisitTime?new Date(n.lastVisitTime).toLocaleString():"";a.innerHTML=`
        <div class="sidebar-item-title">${k(n.title||n.url)}</div>
        <div class="sidebar-item-url">${k(n.url)}</div>
        ${i?`<div class="sidebar-item-time">${k(i)}</div>`:""}
      `,a.addEventListener("click",()=>{window.location.href=n.url}),e.appendChild(a)}}catch{e.innerHTML='<div class="sidebar-empty">Failed to load history</div>'}}function $(){const e=document.getElementById("search-input"),t=document.querySelector(".search-placeholder");!e||!t||(t.textContent=l("placeholder"),t.classList.toggle("hidden",e.value.length>0))}function G(){const e=document.getElementById("search-input"),t=document.querySelector(".search-go");e&&(e.placeholder=""),t&&(t.textContent=l("go")),$(),T()}const Q=/^(?:\d{1,3}\.){3}\d{1,3}$/,Z=/^\[[\da-fA-F:]+\]$/,J=/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i,P=/:\d{1,5}$/;function ee(e){if(/^https?:\/\//i.test(e)||/^[a-z][a-z0-9+\-.]*:\/\//i.test(e))return!0;const t=P.test(e)?e.replace(P,""):e;return!!(Q.test(t)||Z.test(t)||J.test(t))}function te(e){/^[a-z][a-z0-9+\-.]*:\/\//i.test(e)?window.location.href=e:window.location.href="https://"+e}function se(e){if(ee(e)){te(e);return}const t=h(c.searchEngine,z,"browser");t==="browser"&&typeof chrome<"u"&&chrome.search?chrome.search.query({text:e}):t in I&&(window.location.href=I[t]+encodeURIComponent(e))}function W(){const e=h(c.showTitle,["true","false"],"true")==="true",t=h(c.showTime,["true","false"],"false")==="true",s=h(c.showGo,["true","false"],"true")==="true",n=h(c.showShortcuts,["true","false"],"true")==="true",a=h(c.showClickFx,["true","false"],"true")==="true",i=h(c.backgroundStyle,["blank","dots","stripes"],h(c.showDots,["true","false"],"true")==="true"?"dots":"blank"),m=h(c.theme,["auto","light","dark"],"auto"),r=h(c.searchEngine,z,"browser"),u=S(),o=h(c.clockFormat,["12","24"],"24"),d=h(c.searchStyle,["square","rounded","line"],"square");return`
    <button class="menu-item" data-action="toggle-title">
      <span class="menu-label">
        <span class="menu-check ${e?"checked":""}">${e?"&#10003;":""}</span>
        ${l("searchTitle")}
      </span>
    </button>
    <button class="menu-item" data-action="toggle-time">
      <span class="menu-label">
        <span class="menu-check ${t?"checked":""}">${t?"&#10003;":""}</span>
        ${l("timeDisplay")}
      </span>
    </button>
    <button class="menu-item" data-action="toggle-go">
      <span class="menu-label">
        <span class="menu-check ${s?"checked":""}">${s?"&#10003;":""}</span>
        ${l("showGo")}
      </span>
    </button>
    <button class="menu-item" data-action="toggle-shortcuts">
      <span class="menu-label">
        <span class="menu-check ${n?"checked":""}">${n?"&#10003;":""}</span>
        ${l("showShortcuts")}
      </span>
    </button>
    <button class="menu-item" data-action="toggle-clickfx">
      <span class="menu-label">
        <span class="menu-check ${a?"checked":""}">${a?"&#10003;":""}</span>
        ${l("clickEffects")}
      </span>
    </button>
    <div class="menu-separator"></div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("background")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-background" data-value="blank">
          <span class="menu-label">
            <span class="menu-radio ${i==="blank"?"selected":""}"></span>
            ${l("blankBackground")}
          </span>
        </button>
        <button class="menu-item" data-action="set-background" data-value="dots">
          <span class="menu-label">
            <span class="menu-radio ${i==="dots"?"selected":""}"></span>
            ${l("dotBackground")}
          </span>
        </button>
        <button class="menu-item" data-action="set-background" data-value="stripes">
          <span class="menu-label">
            <span class="menu-radio ${i==="stripes"?"selected":""}"></span>
            ${l("stripeBackground")}
          </span>
        </button>
      </div>
    </div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("theme")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-theme" data-value="auto">
          <span class="menu-label">
            <span class="menu-radio ${m==="auto"?"selected":""}"></span>
            ${l("auto")}
          </span>
        </button>
        <button class="menu-item" data-action="set-theme" data-value="light">
          <span class="menu-label">
            <span class="menu-radio ${m==="light"?"selected":""}"></span>
            ${l("light")}
          </span>
        </button>
        <button class="menu-item" data-action="set-theme" data-value="dark">
          <span class="menu-label">
            <span class="menu-radio ${m==="dark"?"selected":""}"></span>
            ${l("dark")}
          </span>
        </button>
      </div>
    </div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("searchEngine")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-engine" data-value="browser">
          <span class="menu-label">
            <span class="menu-radio ${r==="browser"?"selected":""}"></span>
            ${l("browserDefault")}
          </span>
        </button>
        <button class="menu-item" data-action="set-engine" data-value="google">
          <span class="menu-label">
            <span class="menu-radio ${r==="google"?"selected":""}"></span>
            ${l("google")}
          </span>
        </button>
        <button class="menu-item" data-action="set-engine" data-value="duckduckgo">
          <span class="menu-label">
            <span class="menu-radio ${r==="duckduckgo"?"selected":""}"></span>
            ${l("duckduckgo")}
          </span>
        </button>
        <button class="menu-item" data-action="set-engine" data-value="qwant">
          <span class="menu-label">
            <span class="menu-radio ${r==="qwant"?"selected":""}"></span>
            ${l("qwant")}
          </span>
        </button>
        <button class="menu-item" data-action="set-engine" data-value="bing">
          <span class="menu-label">
            <span class="menu-radio ${r==="bing"?"selected":""}"></span>
            ${l("bing")}
          </span>
        </button>
        <button class="menu-item" data-action="set-engine" data-value="baidu">
          <span class="menu-label">
            <span class="menu-radio ${r==="baidu"?"selected":""}"></span>
            ${l("baidu")}
          </span>
        </button>
      </div>
    </div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("clockFormat")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-clock" data-value="12">
          <span class="menu-label">
            <span class="menu-radio ${o==="12"?"selected":""}"></span>
            ${l("clock12h")}
          </span>
        </button>
        <button class="menu-item" data-action="set-clock" data-value="24">
          <span class="menu-label">
            <span class="menu-radio ${o==="24"?"selected":""}"></span>
            ${l("clock24h")}
          </span>
        </button>
      </div>
    </div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("searchStyle")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-style" data-value="square">
          <span class="menu-label">
            <span class="menu-radio ${d==="square"?"selected":""}"></span>
            ${l("square")}
          </span>
        </button>
        <button class="menu-item" data-action="set-style" data-value="rounded">
          <span class="menu-label">
            <span class="menu-radio ${d==="rounded"?"selected":""}"></span>
            ${l("rounded")}
          </span>
        </button>
        <button class="menu-item" data-action="set-style" data-value="line">
          <span class="menu-label">
            <span class="menu-radio ${d==="line"?"selected":""}"></span>
            ${l("line")}
          </span>
        </button>
      </div>
    </div>
    <div class="menu-has-sub">
      <button class="menu-item menu-parent">
        <span class="menu-label">${l("language")}</span>
        <span class="menu-arrow">&#9656;</span>
      </button>
      <div class="menu-submenu">
        <button class="menu-item" data-action="set-lang" data-value="en">
          <span class="menu-label">
            <span class="menu-radio ${u==="en"?"selected":""}"></span>
            ${l("english")}
          </span>
        </button>
        <button class="menu-item" data-action="set-lang" data-value="zh">
          <span class="menu-label">
            <span class="menu-radio ${u==="zh"?"selected":""}"></span>
            ${l("chinese")}
          </span>
        </button>
      </div>
    </div>
  `}function v(){const e=document.getElementById("context-menu");e&&(e.innerHTML=W())}let L=!1;document.addEventListener("DOMContentLoaded",()=>{document.title=S()==="zh"?"新标签页":"New tab",N(h(c.theme,["auto","light","dark"],"auto"));const e=document.getElementById("app");if(e){e.innerHTML=`
      <div class="main">
        <div class="prompt"><span>$</span> search</div>
        <div class="time" id="time"></div>
        <form class="search-form" id="search-form">
          <div class="search-box">
            <input type="text" class="search-input" id="search-input" autofocus>
            <span class="search-placeholder">Type to search...</span>
            <button type="submit" class="search-go" title="Go">Go</button>
          </div>
        </form>
      </div>
      <div class="shortcuts" id="shortcuts">
        <a class="shortcut-item" data-url="chrome://bookmarks" data-i18n="bookmarks"></a>
        <a class="shortcut-item" data-url="chrome://history" data-i18n="history"></a>
        <a class="shortcut-item" data-url="chrome://downloads" data-i18n="downloads"></a>
        <a class="shortcut-item" data-url="chrome://extensions" data-i18n="extensions"></a>
      </div>
    `,x(),R(),O(),B(),w(),G(),T(),A(),setInterval(w,1e3),_();const t=document.createElement("div");t.className="context-menu",t.id="context-menu",t.innerHTML=W(),document.body.appendChild(t);const s=`
      <div class="sidebar-overlay" id="sidebar-overlay"></div>
      <div class="sidebar-panel" id="sidebar-panel">
        <div class="sidebar-header">
          <h3></h3>
          <button class="sidebar-more" id="sidebar-more"></button>
        </div>
        <div class="sidebar-content"></div>
        <div class="sidebar-footer">
          <button class="sidebar-footer-link"></button>
        </div>
      </div>
    `,n=document.createElement("div");for(n.innerHTML=s;n.firstChild;)document.body.appendChild(n.firstChild);document.getElementById("sidebar-overlay").addEventListener("click",D),document.addEventListener("keydown",r=>{r.key==="Escape"&&D()}),t.addEventListener("mouseover",r=>{const u=r.target.closest(".menu-has-sub");if(!u)return;const o=u.querySelector(".menu-submenu");o&&(o.style.left="",o.style.right="",o.style.top="",o.style.bottom="",requestAnimationFrame(()=>{const d=o.getBoundingClientRect();d.right>window.innerWidth&&(o.style.left="auto",o.style.right="100%"),d.bottom>window.innerHeight&&(o.style.top="auto",o.style.bottom="0")}))}),document.addEventListener("contextmenu",r=>{r.preventDefault(),t.classList.add("visible");const u=t.getBoundingClientRect(),o=u.width,d=u.height,b=Math.min(r.clientX,window.innerWidth-o-8),f=Math.min(r.clientY,window.innerHeight-d-8);t.style.left=`${Math.max(0,b)}px`,t.style.top=`${Math.max(0,f)}px`,L=!0}),document.addEventListener("click",()=>{L&&(t.classList.remove("visible"),L=!1)}),t.addEventListener("click",r=>{const u=r.target.closest("[data-action]");if(u){const o=u.dataset.action,d=u.dataset.value||"";switch(o){case"toggle-title":g(c.showTitle,h(c.showTitle,["true","false"],"true")==="true"?"false":"true"),B(),v();break;case"toggle-time":g(c.showTime,h(c.showTime,["true","false"],"false")==="true"?"false":"true"),w(),v();break;case"set-background":g(c.backgroundStyle,d),x(),v();break;case"toggle-go":g(c.showGo,h(c.showGo,["true","false"],"true")==="true"?"false":"true"),R(),v();break;case"toggle-shortcuts":g(c.showShortcuts,h(c.showShortcuts,["true","false"],"true")==="true"?"false":"true"),T(),v();break;case"toggle-clickfx":g(c.showClickFx,h(c.showClickFx,["true","false"],"true")==="true"?"false":"true"),A(),v();break;case"set-theme":N(d),v();break;case"set-engine":g(c.searchEngine,d),v();break;case"set-clock":g(c.clockFormat,d),w(),v();break;case"set-style":g(c.searchStyle,d),O(),v();break;case"set-lang":g(c.lang,d),document.title=d==="zh"?"新标签页":"New tab",G(),v();break}}});const a=document.getElementById("search-form"),i=document.getElementById("search-input"),m=document.querySelector(".search-placeholder");i.addEventListener("focus",()=>{m.classList.add("hidden")}),i.addEventListener("blur",()=>{$()}),i.addEventListener("input",()=>{$()}),a.addEventListener("submit",r=>{r.preventDefault();const u=i.value.trim();u&&se(u)}),document.querySelectorAll(".shortcut-item[data-url]").forEach(r=>{r.addEventListener("click",u=>{u.preventDefault();const o=r.getAttribute("data-url");o==="chrome://bookmarks"?F("bookmarks"):o==="chrome://history"?F("history"):o&&typeof chrome<"u"&&chrome.tabs&&chrome.tabs.create({url:o})})})}});
